package org.example.sushibar.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.example.sushibar.models.MethodStat;
import org.example.sushibar.repositories.MethodStatRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@Aspect
@Component
public class StatisticAspect {

    @Autowired
    private MethodStatRepository repository;

    @Around("@annotation(org.example.sushibar.aop.annotations.LogMethod)")
    public Object recordStats(ProceedingJoinPoint joinPoint) throws Throwable {
        String methodName = joinPoint.getSignature().toShortString();

        long start = System.nanoTime();
        Object result = joinPoint.proceed();  // Proceed with the original method logic
        long duration = System.nanoTime() - start;
        duration /= 1000000;

        MethodStat stat = repository.findByMethodName(methodName)
                .orElseGet(() -> new MethodStat(methodName));

        stat.incrementCount();
        stat.setTotalExecutionTime(stat.getTotalExecutionTime() + duration);
        stat.setMinExecutionTime(Math.min(duration, stat.getMinExecutionTime()));
        stat.setMaxExecutionTime(Math.max(duration, stat.getMaxExecutionTime()));

        // Optional: extract price from response body if needed
        if (result instanceof ResponseEntity<?> responseEntity) {
            Object body = responseEntity.getBody();

            if (body instanceof com.example.models.GetAllMenuItems200Response dto) {
                extractFromList(dto.getContent()).ifPresent(price -> {
                    // stat.setMaxReturnedPrice(price); // enable if you track prices
                });
            } else if (body instanceof Map<?, ?> map) {
                Object content = map.get("content");
                if (content instanceof List<?> list) {
                    extractFromList(list).ifPresent(price -> {
                        // stat.setMaxReturnedPrice(price);
                    });
                }
            } else if (body instanceof List<?> list) {
                extractFromList(list).ifPresent(price -> {
                    // stat.setMaxReturnedPrice(price);
                });
            }
        }

        repository.save(stat);
        return result;
    }

    private Optional<Double> extractFromList(List<?> items) {
        return items.stream()
                .map(this::extractPrice)
                .filter(price -> price > 0)
                .max(Double::compare);
    }

    private double extractPrice(Object item) {
        if (item == null) return 0.0;

        if (item instanceof com.example.models.MenuItem menuItem) {
            return menuItem.getPrice();
        }

        if (item instanceof Map<?, ?> map && map.containsKey("price")) {
            Object priceObj = map.get("price");
            if (priceObj instanceof Number) {
                return ((Number) priceObj).doubleValue();
            } else if (priceObj instanceof String str) {
                try {
                    return Double.parseDouble(str);
                } catch (NumberFormatException e) {
                    return 0.0;
                }
            }
        }

        return 0.0;
    }
}
