package org.example.sushibar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SushiBarApplication {
    public static void main(String[] args) {
        SpringApplication.run(SushiBarApplication.class, args);
    }
}
